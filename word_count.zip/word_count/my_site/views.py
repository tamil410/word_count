from ast import operator
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
'''
def count(request):
    data=request.GET['text', False]
    data=data.casefold()
    word_list=data.split()
    list_length=len(word_list)
    worddictionary={}
    for word in word_list:
        if word in worddictionary:
            worddictionary[word] +=1
        elif (word==" "):
            pass
        else:
            worddictionary[word] = 1
    #sorted_list=sorted(worddictionary.items(), reverse=True)
    return render (request, 'count.html', {'worddictionary':worddictionary.items()})

'''
