from django.shortcuts import render
from django.http import HttpResponse, HttpResponseNotFound
from django.shortcuts import render,redirect
from .forms import CreateUserForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from ast import operator
# Create your views here.

def home(request):
    if request.method=='POST':
        data1=str(request.POST.get('text',''))
        data=data1.casefold()
        word_list=data.split()
        list_length=len(word_list)
        worddictionary={}
        for word in word_list:
            if word in worddictionary:
                worddictionary[word] +=1
            elif (word==" "):
                pass
            else:
                worddictionary[word] = 1
        sort_list=sorted(worddictionary.items(), reverse=True, key=lambda kv:(kv[1],kv[0]))
        sorted_list=dict((sort_list)[0:10])
        return render (request, 'home.html', {'worddictionary':sorted_list.items(),'text':data1})

    else:
        return render (request, 'home.html')

